---
name: Institutional Heritage Dashboard
colors:
  surface: '#f7fafc'
  surface-dim: '#d7dadc'
  surface-bright: '#f7fafc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f6'
  surface-container: '#ebeef0'
  surface-container-high: '#e5e9eb'
  surface-container-highest: '#e0e3e5'
  on-surface: '#181c1e'
  on-surface-variant: '#44474d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f3'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#4e5f7e'
  primary: '#031632'
  on-primary: '#ffffff'
  primary-container: '#1a2b48'
  on-primary-container: '#8293b5'
  inverse-primary: '#b6c7eb'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#001c0c'
  on-tertiary: '#ffffff'
  tertiary-container: '#00331a'
  on-tertiary-container: '#49a46d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#b6c7eb'
  on-primary-fixed: '#081b38'
  on-primary-fixed-variant: '#374765'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#9af6b8'
  tertiary-fixed-dim: '#7ed99e'
  on-tertiary-fixed: '#00210f'
  on-tertiary-fixed-variant: '#00522d'
  background: '#f7fafc'
  on-background: '#181c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Public Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  title-sm:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.4'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  data-tabular:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 24px
  gutter: 20px
  component-gap: 12px
  section-margin: 32px
---

## Brand & Style

The design system is anchored in the principles of stewardship, clarity, and academic prestige. It is designed for administrators and curators who require a high-density information environment that remains calm and legible under pressure. The brand personality is "The Modern Archivist"—combining the weight of history with the efficiency of modern data science.

The visual style follows a **Corporate / Modern** aesthetic with a lean toward minimalism. It prioritizes functional whitespace and a rigid structural hierarchy to instill a sense of order and reliability across the 14 managed institutions. The emotional response should be one of quiet confidence, ensuring that the diverse cultural data remains the focal point while the interface provides a stable, unobtrusive framework.

## Colors

The palette is curated to reflect institutional authority and cultural richness.

- **Primary (Deep Navy):** Used for navigation, primary actions, and headers to establish a "foundation of trust."
- **Secondary (Soft Gold):** Reserved for cultural highlights, premium features, and key performance indicators related to heritage.
- **Tertiary (Emerald Green):** Dedicated to growth metrics, positive trends, and financial health.
- **Neutral (Light Gray):** The primary background color, used to reduce eye strain and provide a clean canvas for data.
- **Accent (Muted Orange):** Specifically utilized for system alerts and areas requiring immediate administrative attention.

Backgrounds should utilize the neutral wash to differentiate the workspace from the pure white (`#FFFFFF`) used for interactive cards and data containers.

## Typography

This design system utilizes a dual-font strategy to balance institutional authority with technical utility. **Public Sans** is used for headlines and titles to provide a sturdy, government-grade legibility. **Inter** is used for all body copy, data points, and UI labels due to its exceptional performance in high-density dashboard environments.

For data visualizations and tables, "tabular-nums" must be enabled to ensure vertical alignment of digits across museum comparison reports.

## Layout & Spacing

The layout employs a **Fixed Grid** system for the primary content area, centered within the viewport on large displays to maintain focus. The dashboard follows a 12-column structure with 20px gutters.

The spacing rhythm is built on a 4px baseline. Standardized padding for dashboard cards is 24px to ensure data density doesn't compromise readability. Margins between distinct museum profile sections are set to 32px to provide clear visual separation between the 14 different entities.

## Elevation & Depth

Hierarchy in this design system is achieved through **Tonal Layers** and **Ambient Shadows**. 

The base layer is the light gray background. Interactive components and data cards sit on the first elevation layer (pure white) with a very soft, diffused shadow (0px 4px 12px, 5% opacity of the primary navy). Higher elevation is used exclusively for modals and dropdown menus, which feature a slightly more pronounced shadow (0px 8px 24px, 10% opacity) to signify temporary focus. Borders should be kept minimal, using a 1px stroke in a light gray-blue to define card boundaries without adding visual noise.

## Shapes

The design system adopts a **Rounded** shape language to soften the institutional feel and make the software feel modern and accessible.

Standard buttons, input fields, and small cards utilize an 8px radius. Large dashboard containers and museum overview cards use a 12px or 16px radius. This subtle curvature maintains a professional appearance while avoiding the severity of sharp corners or the casual nature of fully pill-shaped elements.

## Components

- **Data Cards:** The core component. Must feature a 1px border (`#E1E8ED`) and 12px rounded corners. Headers within cards should use the primary navy for titles.
- **Buttons:** Primary buttons are solid Navy (#1A2B48) with white text. Secondary buttons use a Navy outline. Ghost buttons are reserved for utility actions within tables.
- **Chips:** Used for museum categories or status tags. These should have a light tinted background of the category color with 100% opacity text for high contrast.
- **Inputs:** Standardized 8px radius with a 1px border. On focus, the border shifts to the primary navy with a subtle 2px glow.
- **Iconography:** Use minimalist 2px stroke outline icons. Avoid solid fills unless indicating an active state in the side navigation.
- **Museum Comparison Tables:** Rows should have a hover state of 2% primary navy to help the eye track data across wide screens.
- **Progress Bars:** Use the Tertiary Emerald for progress and the Neutral Gray for the track.