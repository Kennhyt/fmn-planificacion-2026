# Plan de Pruebas - Aplicativo Gestión POA 2026

Este documento guía el proceso de validación para asegurar que el sistema cumpla con todos los requisitos técnicos de la Fundación Museos Nacionales.

## 1. Validación de Acceso
- Probar ingreso con los correos autorizados: `gestioneducativafmn@gmail.com` y `coordinacionanalisis.fmn@gmail.com`.
- Verificar recuperación de acceso por correo.

## 2. Flujo de Carga Individual (Museos)
- Ingresar al Dashboard de un museo (ej. MUJABO).
- Cargar una actividad de Acción 1 (Capacitación) completando todos los campos (Nombre, Programa, Beneficiarios, Comuna).
- Validar que el sistema acepte valor '0' en beneficiarios si no hubo asistencia.
- Intentar cargar la misma comuna dos veces para verificar la alerta de duplicidad.

## 3. Flujo de Carga Masiva (Excel)
- Subir archivo Excel con múltiples registros.
- Validar la pantalla de "Previsualización de Datos".
- Confirmar que el sistema identifique errores de formato o códigos de comuna inexistentes antes de procesar.

## 4. Validación de Trazabilidad (Trimestral)
- Intentar registrar una Feria (Acción 2) sin haber registrado previamente la Capacitación (Acción 1) vinculada a esa misma comuna.
- Confirmar que el sistema bloquee el registro y muestre la alerta de "Error de Trazabilidad".

## 5. Módulo de Administración Central
- Revisar el "Centro de Alertas" para ver las incidencias reportadas por los museos.
- Ejecutar el envío de una "Notificación de Urgencia".
- Verificar que el historial de auditoría registre quién realizó cada cambio.

## 6. Reportes Ejecutivos
- Generar el "Libro del POA 2026" y verificar que no existan errores de caracteres especiales.
- Validar que las gráficas reflejen los datos cargados en tiempo real.
- Exportar reporte a Excel y verificar legibilidad.
