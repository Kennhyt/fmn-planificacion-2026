# Guía de Conexión: Aplicativo POA 2026 a Google Looker Studio

Esta guía detalla los pasos técnicos para exportar la data del sistema de la Fundación Museos Nacionales y transformarla en un tablero de control visual y ejecutivo.

## Paso 1: Exportación desde el Aplicativo
1. Ingrese al módulo de **Exportación Looker Studio** en el aplicativo.
2. Haga clic en el botón **"Descargar Data Consolidada (CSV/Excel)"**.
3. Guarde el archivo en su computador. El sistema garantiza que el archivo esté codificado en UTF-8 para evitar errores de caracteres (acentos y eñes).

## Paso 2: Preparación en Google Sheets
1. Abra una nueva hoja de cálculo en su cuenta de Google (Sheets).
2. Vaya a **Archivo > Importar** y suba el archivo que descargó en el Paso 1.
3. Asegúrese de que la primera fila contenga los nombres de las columnas (Código Actividad, Programa, Acción, Comuna, etc.).

## Paso 3: Configuración en Google Looker Studio
1. Acceda a [lookerstudio.google.com](https://lookerstudio.google.com).
2. Haga clic en **Crear > Fuente de datos**.
3. Seleccione el conector de **Google Sheets**.
4. Elija la hoja de cálculo que acaba de crear y haga clic en **Conectar**.

## Paso 4: Creación del Dashboard Ejecutivo
1. Una vez conectada la data, haga clic en **Crear Informe**.
2. Utilice los campos de "Acción POA" para crear gráficos de barras que comparen la Acción 1 vs Acción 2.
3. Use el campo "Comuna" para crear filtros de ubicación.
4. Aplique los colores institucionales (#1A2B48 para el azul profundo) para mantener la elegancia y coherencia visual.

---
**Nota Técnica:** Para una automatización completa, puede usar el "Enlace de Sincronización Directa" del aplicativo para evitar descargar el archivo manualmente cada vez.
